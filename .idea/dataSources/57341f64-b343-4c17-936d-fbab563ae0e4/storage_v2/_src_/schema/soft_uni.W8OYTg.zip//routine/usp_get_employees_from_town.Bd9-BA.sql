create
    definer = root@localhost procedure usp_get_employees_from_town(IN town_name varchar(10))
begin
	select first_name, last_name
    from employees as e
    join addresses as a
    on e.address_id = a.address_id
    join towns as t
    on a.town_id = t.town_id
    where t.`name` = town_name
    order by first_name, last_name, e.employee_id;
end;

