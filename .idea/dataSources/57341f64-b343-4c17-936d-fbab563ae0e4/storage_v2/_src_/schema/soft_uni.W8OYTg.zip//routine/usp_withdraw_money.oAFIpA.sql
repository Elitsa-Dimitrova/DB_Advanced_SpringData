create
    definer = root@localhost procedure usp_withdraw_money(IN account_id int, IN money_amount double(20, 4))
begin

	declare curr double;
    set curr = round((select balance from accounts where id = account_id),4);
	start transaction;
    
    if (money_amount<0)
    then rollback;
    else if ( curr - money_amount < 0)
    then rollback;
    else
    update accounts as a
    set a.balance = a.balance - money_amount
    where a.id = account_id;
    end if;
    end if;
    
end;

