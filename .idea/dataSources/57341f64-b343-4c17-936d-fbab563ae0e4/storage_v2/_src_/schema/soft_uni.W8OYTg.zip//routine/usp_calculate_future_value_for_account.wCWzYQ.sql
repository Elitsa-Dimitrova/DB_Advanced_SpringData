create
    definer = root@localhost procedure usp_calculate_future_value_for_account(IN account_id int, IN interest_rate double)
begin 
    
	select account_id, first_name, last_name, a.balance as current_balance,
    round((a.balance * POW(1 + interest_rate, 5)),4)
    as balance_in_5_years
    from account_holders as ah
    join accounts as a
    on a.account_holder_id = ah.id
	where a.id=account_id;
end;

