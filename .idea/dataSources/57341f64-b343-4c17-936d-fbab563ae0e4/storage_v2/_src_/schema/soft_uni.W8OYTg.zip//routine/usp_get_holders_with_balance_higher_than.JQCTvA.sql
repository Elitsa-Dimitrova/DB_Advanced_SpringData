create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN min_amount decimal)
begin
	select first_name, last_name
    from account_holders as ah
    join accounts as a
    on ah.id = a.account_holder_id
	group by a.account_holder_id
	having sum(a.balance) > min_amount
    order by ah.id;
end;

