create
    definer = root@localhost procedure usp_get_employees_salary_above(IN min_salary decimal)
begin
	select first_name, last_name
    from employees
    where salary >= min_salary
    order by first_name, last_name, employee_id;
end;

