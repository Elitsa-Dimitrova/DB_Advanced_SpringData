create
    definer = root@localhost procedure usp_deposit_money(IN account_id int, IN money_amount double(10, 4))
begin 
    
    start transaction;
	if (money_amount < 0)
    then rollback;
    else 
    update accounts
    set balance = balance + money_amount
    where accounts.id = account_id;
    end if;
end;

