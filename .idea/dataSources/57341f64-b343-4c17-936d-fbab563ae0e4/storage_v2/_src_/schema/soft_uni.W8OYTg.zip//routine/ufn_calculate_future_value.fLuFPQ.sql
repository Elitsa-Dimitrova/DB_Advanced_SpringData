create
    definer = root@localhost function ufn_calculate_future_value(I decimal, R decimal, T int) returns decimal
begin
	
	declare result decimal;
    
    set result := I * pow((1+R),T);
    
    return result;
end;

