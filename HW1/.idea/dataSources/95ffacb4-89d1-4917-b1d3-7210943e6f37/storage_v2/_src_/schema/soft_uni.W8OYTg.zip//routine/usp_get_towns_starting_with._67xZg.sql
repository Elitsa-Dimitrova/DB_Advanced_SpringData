create
    definer = root@localhost procedure usp_get_towns_starting_with(IN start_name varchar(10))
begin
	select `name`
    from towns
    where `name` like concat(start_name, '%')
    order by `name`;
end;

